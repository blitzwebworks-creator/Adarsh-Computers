import { cn } from "@/lib/utils";

export function Badge({ className, children, ...props }: React.HTMLAttributes<HTMLSpanElement>) {
  return <span className={cn("inline-flex items-center rounded-full bg-secondary px-3 py-1 text-xs font-bold text-secondary-foreground", className)} {...props}>{children}</span>;
}
